from setuptools import setup

setup(
    name='roboter',
    version='1.0.0',
    packages=[''],
    url='',
    license='free',
    author='sakaguchitakuya',
    author_email='takuya1002@gmail.com',
    description=''
)
